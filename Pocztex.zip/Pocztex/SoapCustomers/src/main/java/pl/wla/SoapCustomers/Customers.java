package pl.wla.SoapCustomers;

import javax.jws.WebMethod;
import javax.jws.WebResult;
import javax.jws.WebService;

@WebService(targetNamespace="CustomerService")
public interface Customers {
@WebMethod(action="getVersion")
@WebResult(name="version")
public String getVer();
}
