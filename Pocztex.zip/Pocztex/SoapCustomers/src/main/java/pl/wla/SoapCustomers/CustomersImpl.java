package pl.wla.SoapCustomers;

public class CustomersImpl implements Customers {

	public String getVer() {
		return "1.0";
	}

}
