package pl.wla.lambdaFactory;

public class Validator {
	ValidatorStrategy strategy;

	public Validator(ValidatorStrategy strategy) {
		this.strategy = strategy;
	}

	public boolean validate(String s) {
		return strategy.execute(s);
	}
}
