package pl.wla.lambdaFactory;

import java.util.concurrent.Callable;

public class Job implements Callable<String> {

	@Override
	public String call() throws MyJobException {
		// TODO Auto-generated method stub
		return "done";
	}

}
