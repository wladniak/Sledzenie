package pl.wla.lambdaFactory;


public interface ValidatorStrategy {
	boolean execute(String s);
}
