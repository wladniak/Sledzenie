package pl.wla.lambdaFactory;

public class IsAllLowerCase implements ValidatorStrategy {

	public boolean execute(String s) {
		// TODO Auto-generated method stub
		return s.matches("[a-z]+");
	}

}
