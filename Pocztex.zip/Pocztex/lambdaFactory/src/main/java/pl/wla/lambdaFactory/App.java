package pl.wla.lambdaFactory;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;
import java.util.ResourceBundle;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		Validator v1 = new Validator(new IsNumeric());
		System.out.println(v1.validate("alalaklsk"));

		Validator v2 = new Validator(new IsAllLowerCase());
		System.out.println(v2.validate("ok"));

		Validator v3 = new Validator(s -> s.matches("\\d+"));
		System.out.println(v3.validate("alalaklsk"));

		Validator v4 = new Validator(s -> s.matches("[a-z]+"));
		System.out.println(v4.validate("ok"));

		OnlineBankingNoLambda obnl = new OnlineBankingNoLambda();
		obnl.processCustomer(222);

		new OnlineBankingLambda().processCustomer(9, c -> System.out.println(c.getName() + c.getId()));

		ResourceBundle r = ResourceBundle.getBundle("wojtek", Locale.FRANCE);
		System.out.println(r.getString("wojtek"));

		Collection<String> coll = new ArrayList<>();
		coll.add("a");
		coll.add("b");
		coll.add("c");
		System.out.println("coll is " + coll);
		coll.remove(0);
		System.out.println("coll is " + coll);

		Path p = Paths.get("a", "b", "cee");
		System.out.println(p);
		System.out.println(p.endsWith(Paths.get("b", "cee")));
		System.out.println(p.endsWith(Paths.get("ee")));

		try (MyRessource r1 = new MyRessource("one"); MyRessource r2 = new MyRessource("two")) {

		} finally {
			System.out.println("three");
		}

	}
}
