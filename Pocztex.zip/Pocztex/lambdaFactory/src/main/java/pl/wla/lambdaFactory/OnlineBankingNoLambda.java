package pl.wla.lambdaFactory;

public class OnlineBankingNoLambda extends OnlineBanking {

	@Override
	void makeCustomerHappy(Customer c) {
		// TODO Auto-generated method stub
		System.out.println(c.getId() + c.getName());
	}

}
