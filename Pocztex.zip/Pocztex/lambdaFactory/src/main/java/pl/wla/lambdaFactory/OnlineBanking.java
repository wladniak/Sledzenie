package pl.wla.lambdaFactory;

public abstract class OnlineBanking {
	public void processCustomer(int id) {
		Customer c = new Customer("ala", 100);
		makeCustomerHappy(c);
	}

	abstract void makeCustomerHappy(Customer c);
}
