package pl.wla.lambdaFactory;

public class IsNumeric implements ValidatorStrategy {

	public boolean execute(String s) {
		// TODO Auto-generated method stub
		return s.matches("\\d+");
	}

}
