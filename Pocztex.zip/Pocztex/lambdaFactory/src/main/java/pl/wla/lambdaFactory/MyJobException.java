package pl.wla.lambdaFactory;

public class MyJobException extends Exception {

}
