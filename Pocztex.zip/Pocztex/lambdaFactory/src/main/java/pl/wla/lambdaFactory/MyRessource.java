package pl.wla.lambdaFactory;

public class MyRessource implements AutoCloseable {
	String name;

	public MyRessource(String name) {
		this.name = name;
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		System.out.println(name);
	}

}
