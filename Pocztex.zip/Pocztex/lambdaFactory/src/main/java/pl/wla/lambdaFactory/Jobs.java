package pl.wla.lambdaFactory;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class Jobs {
	public static void main(String[] args) {
		ExecutorService es = Executors.newFixedThreadPool(3);
		Future<String> handle = es.submit(new Job());
		try {
			String rv = handle.get();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
