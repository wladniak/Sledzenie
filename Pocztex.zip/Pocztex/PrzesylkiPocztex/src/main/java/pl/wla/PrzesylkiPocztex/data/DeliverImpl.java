package pl.wla.PrzesylkiPocztex.data;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import pl.wla.PrzesylkiPocztex.data.interfaces.Delivery;

@Component
@Profile("prod")
public class DeliverImpl implements Delivery {
	@Autowired
	Track track;

	private String text;

	@PostConstruct
	private void init() {
		text = "ale ma kota";
		System.out.println("post construct bean DeliverImpl");
	}

	public void printData(String numer) {
System.out.println("prod profile");
		track.getDane(numer);

		System.out.println(this.text);
	}

}
