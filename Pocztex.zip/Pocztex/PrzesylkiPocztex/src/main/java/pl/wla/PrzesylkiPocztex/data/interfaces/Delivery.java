package pl.wla.PrzesylkiPocztex.data.interfaces;

public interface Delivery {
	public void printData(String numer);
}
