package pl.wla.PrzesylkiPocztex.soap;

public class HandlerProvider {

}
