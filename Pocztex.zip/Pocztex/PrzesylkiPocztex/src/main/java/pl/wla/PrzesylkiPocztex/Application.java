package pl.wla.PrzesylkiPocztex;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import pl.wla.PrzesylkiPocztex.data.interfaces.Delivery;

@Component
public class Application {
	private String numer;

	@Autowired
	private Delivery delivery;

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = null;
		try {
			ctx = new AnnotationConfigApplicationContext();
		//	ctx.getEnvironment().setDefaultProfiles("dev");

			ctx.getEnvironment().setActiveProfiles("dev");

			System.out.println(ctx.getEnvironment().getActiveProfiles().length);
			ctx.register(AppConfig.class);
			ctx.refresh();
			Application app = (Application) ctx.getBean("application");
			app.numer = "00259007731198440730";
			app.checkDelivery();

		} finally {
			if (ctx != null) {
				ctx.close();
			}
		}
	}

	private void checkDelivery() {
		delivery.printData(numer);
	}

}