package pl.wla.PrzesylkiPocztex.data;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.handler.Handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import pl.pocztapolska.sledzenie.Sledzenie;
import pl.pocztapolska.sledzenie.SledzeniePortType;
import pl.pocztapolska.sledzenie.ws.xsd.DanePrzesylki;
import pl.pocztapolska.sledzenie.ws.xsd.Jednostka;
import pl.pocztapolska.sledzenie.ws.xsd.Przesylka;
import pl.pocztapolska.sledzenie.ws.xsd.Przyczyna;
import pl.pocztapolska.sledzenie.ws.xsd.SzczDaneJednostki;
import pl.pocztapolska.sledzenie.ws.xsd.Zdarzenie;
import pl.wla.PrzesylkiPocztex.soap.HandlerProvider;

@Component
public class Track {
	@Autowired
	Sledzenie sledzenie;

	@Autowired
	Handler myHandler;

	SledzeniePortType myServicePort;

	@PostConstruct
	private void postInit() {
		myServicePort = sledzenie.getSledzenieHttpSoap11Endpoint();
		// This is the block that apply the Ws Security to the request
		BindingProvider bindingProvider = (BindingProvider) myServicePort;
		@SuppressWarnings("rawtypes")
		List<Handler> handlerChain = new ArrayList<Handler>();
		handlerChain.add(myHandler);
		bindingProvider.getBinding().setHandlerChain(handlerChain);
	}

	public void getDane(String numer) {
		System.out.println("track sdjakljdklaj");

		Przesylka p = myServicePort.sprawdzPrzesylkePl(numer);
		System.out.println(p.getStatus());
		if (p.getStatus() != -1) {

			DanePrzesylki d = p.getDanePrzesylki().getValue();
			System.out.println(d.getNumer().getValue());
			System.out.println(d.getDataNadania().getValue());
			System.out.println(d.getRodzPrzes().getValue());
			System.out.println(d.getKrajNadania().getValue());
			System.out.println(d.getKrajPrzezn().getValue());
			System.out.println("Jednoska nadania");
			Jednostka jednNadania = d.getUrzadNadania().getValue();

			System.out.println(jednNadania.getNazwa().getValue());
			SzczDaneJednostki szczjedn = jednNadania.getDaneSzczegolowe().getValue();
			System.out.println(jednNadania.getNazwa().getValue() + "(" + szczjedn.getUlica().getValue() + " "
					+ szczjedn.getNrDomu().getValue() + " " + szczjedn.getPna().getValue() + " "
					+ szczjedn.getMiejscowosc().getValue() + " Czynne: "
					+ szczjedn.getGodzinyPracy().getValue().getDniRobocze().getValue().getGodziny().getValue() + ")");

			System.out.println("Jednoska przeznaczania");
			Jednostka jednPrzezn = d.getUrzadPrzezn().getValue();

			System.out.println(jednPrzezn.getNazwa().getValue());
			szczjedn = jednPrzezn.getDaneSzczegolowe().getValue();
			System.out.println(jednPrzezn.getNazwa().getValue() + "(" + szczjedn.getUlica().getValue() + " "
					+ szczjedn.getNrDomu().getValue() + " " + szczjedn.getPna().getValue() + " "
					+ szczjedn.getMiejscowosc().getValue() + " Czynne: "
					+ szczjedn.getGodzinyPracy().getValue().getDniRobocze().getValue().getGodziny().getValue() + ")");

			System.out.println(d.getKodRodzPrzes().getValue());
			System.out.println(d.getMasa().getValue());

			List<Zdarzenie> l = d.getZdarzenia().getValue().getZdarzenie();
			for (Zdarzenie z : l) {
				System.out.println("============ Nowe Zdarzenie =============");
				System.out.println(z.getCzas().getValue() + " " + z.getNazwa().getValue());
				// System.out.println(z.getKod().getValue());
				Przyczyna prz = z.getPrzyczyna().getValue();
				if (prz != null) {
					System.out.println(prz.getNazwa().getValue());
				}
				Jednostka j = z.getJednostka().getValue();

				System.out.println(j.getNazwa().getValue());
				szczjedn = j.getDaneSzczegolowe().getValue();
				System.out.println(j.getNazwa().getValue() + "(" + szczjedn.getUlica().getValue() + " "
						+ szczjedn.getNrDomu().getValue() + " " + szczjedn.getPna().getValue() + " "
						+ szczjedn.getMiejscowosc().getValue() + " Czynne: "
						+ szczjedn.getGodzinyPracy().getValue().getDniRobocze().getValue().getGodziny().getValue()
						+ ")");

			}
		}
	}

}
