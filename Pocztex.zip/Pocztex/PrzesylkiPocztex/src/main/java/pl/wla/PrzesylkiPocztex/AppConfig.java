package pl.wla.PrzesylkiPocztex;

import javax.xml.ws.handler.Handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import pl.pocztapolska.sledzenie.Sledzenie;
import pl.wla.PrzesylkiPocztex.data.User;
import pl.wla.PrzesylkiPocztex.soap.WSSecurityHeaderSOAPHandler;

@Configuration
@ComponentScan(basePackages = { "pl.wla.PrzesylkiPocztex*" })
@PropertySource("classpath:/pl/wla/PrzesylkiPocztex/app.properties")
public class AppConfig {
	@Autowired
	Environment env;

	@Bean
	Sledzenie sledzBean() {
		return new Sledzenie();
	}

	@Bean
	User user() {
		return new User(env.getProperty("usr"), env.getProperty("pwd"));
	}

	@Bean
	Handler myHandlerBean() {
		return new WSSecurityHeaderSOAPHandler(user());
	}

}
