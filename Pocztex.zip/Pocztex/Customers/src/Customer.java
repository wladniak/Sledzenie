import javax.jws.WebService;

@WebService(targetNamespace="CustomerService")
public interface Customer {
public String version(); 
}
