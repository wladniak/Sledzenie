import javax.jws.WebService;

@WebService(serviceName="customer",targetNamespace="CustomerNameSpace")
public class CustomerImpl implements Customer {

	@Override
	public String version() {
		return "1.0";
	}

}
