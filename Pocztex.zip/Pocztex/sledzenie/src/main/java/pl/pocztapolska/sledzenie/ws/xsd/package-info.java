@javax.xml.bind.annotation.XmlSchema(namespace = "http://ws.sledzenie.pocztapolska.pl/xsd", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package pl.pocztapolska.sledzenie.ws.xsd;
