
package pl.pocztapolska.sledzenie;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;
import pl.pocztapolska.sledzenie.ws.xsd.Komunikat;
import pl.pocztapolska.sledzenie.ws.xsd.Przesylka;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the pl.pocztapolska.sledzenie package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _WersjaResponseReturn_QNAME = new QName("http://sledzenie.pocztapolska.pl", "return");
    private final static QName _SprawdzPrzesylkePlNumer_QNAME = new QName("http://sledzenie.pocztapolska.pl", "numer");
    private final static QName _SprawdzPrzesylkiOdDoOdDnia_QNAME = new QName("http://sledzenie.pocztapolska.pl", "odDnia");
    private final static QName _SprawdzPrzesylkiOdDoDoDnia_QNAME = new QName("http://sledzenie.pocztapolska.pl", "doDnia");
    private final static QName _WitajImie_QNAME = new QName("http://sledzenie.pocztapolska.pl", "imie");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: pl.pocztapolska.sledzenie
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkiResponse }
     * 
     */
    public SprawdzPrzesylkiResponse createSprawdzPrzesylkiResponse() {
        return new SprawdzPrzesylkiResponse();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkePl }
     * 
     */
    public SprawdzPrzesylkePl createSprawdzPrzesylkePl() {
        return new SprawdzPrzesylkePl();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkiOdDoPl }
     * 
     */
    public SprawdzPrzesylkiOdDoPl createSprawdzPrzesylkiOdDoPl() {
        return new SprawdzPrzesylkiOdDoPl();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkePlResponse }
     * 
     */
    public SprawdzPrzesylkePlResponse createSprawdzPrzesylkePlResponse() {
        return new SprawdzPrzesylkePlResponse();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylki }
     * 
     */
    public SprawdzPrzesylki createSprawdzPrzesylki() {
        return new SprawdzPrzesylki();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkiPlResponse }
     * 
     */
    public SprawdzPrzesylkiPlResponse createSprawdzPrzesylkiPlResponse() {
        return new SprawdzPrzesylkiPlResponse();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkiOdDo }
     * 
     */
    public SprawdzPrzesylkiOdDo createSprawdzPrzesylkiOdDo() {
        return new SprawdzPrzesylkiOdDo();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkiOdDoPlResponse }
     * 
     */
    public SprawdzPrzesylkiOdDoPlResponse createSprawdzPrzesylkiOdDoPlResponse() {
        return new SprawdzPrzesylkiOdDoPlResponse();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylke }
     * 
     */
    public SprawdzPrzesylke createSprawdzPrzesylke() {
        return new SprawdzPrzesylke();
    }

    /**
     * Create an instance of {@link WersjaResponse }
     * 
     */
    public WersjaResponse createWersjaResponse() {
        return new WersjaResponse();
    }

    /**
     * Create an instance of {@link WitajResponse }
     * 
     */
    public WitajResponse createWitajResponse() {
        return new WitajResponse();
    }

    /**
     * Create an instance of {@link MaksymalnaLiczbaPrzesylekResponse }
     * 
     */
    public MaksymalnaLiczbaPrzesylekResponse createMaksymalnaLiczbaPrzesylekResponse() {
        return new MaksymalnaLiczbaPrzesylekResponse();
    }

    /**
     * Create an instance of {@link Witaj }
     * 
     */
    public Witaj createWitaj() {
        return new Witaj();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkeResponse }
     * 
     */
    public SprawdzPrzesylkeResponse createSprawdzPrzesylkeResponse() {
        return new SprawdzPrzesylkeResponse();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkiOdDoResponse }
     * 
     */
    public SprawdzPrzesylkiOdDoResponse createSprawdzPrzesylkiOdDoResponse() {
        return new SprawdzPrzesylkiOdDoResponse();
    }

    /**
     * Create an instance of {@link SprawdzPrzesylkiPl }
     * 
     */
    public SprawdzPrzesylkiPl createSprawdzPrzesylkiPl() {
        return new SprawdzPrzesylkiPl();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "return", scope = WersjaResponse.class)
    public JAXBElement<String> createWersjaResponseReturn(String value) {
        return new JAXBElement<String>(_WersjaResponseReturn_QNAME, String.class, WersjaResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "return", scope = WitajResponse.class)
    public JAXBElement<String> createWitajResponseReturn(String value) {
        return new JAXBElement<String>(_WersjaResponseReturn_QNAME, String.class, WitajResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Komunikat }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "return", scope = SprawdzPrzesylkiResponse.class)
    public JAXBElement<Komunikat> createSprawdzPrzesylkiResponseReturn(Komunikat value) {
        return new JAXBElement<Komunikat>(_WersjaResponseReturn_QNAME, Komunikat.class, SprawdzPrzesylkiResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "numer", scope = SprawdzPrzesylkePl.class)
    public JAXBElement<String> createSprawdzPrzesylkePlNumer(String value) {
        return new JAXBElement<String>(_SprawdzPrzesylkePlNumer_QNAME, String.class, SprawdzPrzesylkePl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Przesylka }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "return", scope = SprawdzPrzesylkePlResponse.class)
    public JAXBElement<Przesylka> createSprawdzPrzesylkePlResponseReturn(Przesylka value) {
        return new JAXBElement<Przesylka>(_WersjaResponseReturn_QNAME, Przesylka.class, SprawdzPrzesylkePlResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "numer", scope = SprawdzPrzesylke.class)
    public JAXBElement<String> createSprawdzPrzesylkeNumer(String value) {
        return new JAXBElement<String>(_SprawdzPrzesylkePlNumer_QNAME, String.class, SprawdzPrzesylke.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Komunikat }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "return", scope = SprawdzPrzesylkiPlResponse.class)
    public JAXBElement<Komunikat> createSprawdzPrzesylkiPlResponseReturn(Komunikat value) {
        return new JAXBElement<Komunikat>(_WersjaResponseReturn_QNAME, Komunikat.class, SprawdzPrzesylkiPlResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "odDnia", scope = SprawdzPrzesylkiOdDo.class)
    public JAXBElement<String> createSprawdzPrzesylkiOdDoOdDnia(String value) {
        return new JAXBElement<String>(_SprawdzPrzesylkiOdDoOdDnia_QNAME, String.class, SprawdzPrzesylkiOdDo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "doDnia", scope = SprawdzPrzesylkiOdDo.class)
    public JAXBElement<String> createSprawdzPrzesylkiOdDoDoDnia(String value) {
        return new JAXBElement<String>(_SprawdzPrzesylkiOdDoDoDnia_QNAME, String.class, SprawdzPrzesylkiOdDo.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "imie", scope = Witaj.class)
    public JAXBElement<String> createWitajImie(String value) {
        return new JAXBElement<String>(_WitajImie_QNAME, String.class, Witaj.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Przesylka }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "return", scope = SprawdzPrzesylkeResponse.class)
    public JAXBElement<Przesylka> createSprawdzPrzesylkeResponseReturn(Przesylka value) {
        return new JAXBElement<Przesylka>(_WersjaResponseReturn_QNAME, Przesylka.class, SprawdzPrzesylkeResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Komunikat }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "return", scope = SprawdzPrzesylkiOdDoPlResponse.class)
    public JAXBElement<Komunikat> createSprawdzPrzesylkiOdDoPlResponseReturn(Komunikat value) {
        return new JAXBElement<Komunikat>(_WersjaResponseReturn_QNAME, Komunikat.class, SprawdzPrzesylkiOdDoPlResponse.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "odDnia", scope = SprawdzPrzesylkiOdDoPl.class)
    public JAXBElement<String> createSprawdzPrzesylkiOdDoPlOdDnia(String value) {
        return new JAXBElement<String>(_SprawdzPrzesylkiOdDoOdDnia_QNAME, String.class, SprawdzPrzesylkiOdDoPl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "doDnia", scope = SprawdzPrzesylkiOdDoPl.class)
    public JAXBElement<String> createSprawdzPrzesylkiOdDoPlDoDnia(String value) {
        return new JAXBElement<String>(_SprawdzPrzesylkiOdDoDoDnia_QNAME, String.class, SprawdzPrzesylkiOdDoPl.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Komunikat }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://sledzenie.pocztapolska.pl", name = "return", scope = SprawdzPrzesylkiOdDoResponse.class)
    public JAXBElement<Komunikat> createSprawdzPrzesylkiOdDoResponseReturn(Komunikat value) {
        return new JAXBElement<Komunikat>(_WersjaResponseReturn_QNAME, Komunikat.class, SprawdzPrzesylkiOdDoResponse.class, value);
    }

}
