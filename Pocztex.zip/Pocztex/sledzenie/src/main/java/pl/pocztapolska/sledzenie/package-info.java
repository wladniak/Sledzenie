/**
 * Sledzenie przesylek Poczty Polskiej S.A. dla klientow indywidualnych. - 0.69 
 * 
 */
@javax.xml.bind.annotation.XmlSchema(namespace = "http://sledzenie.pocztapolska.pl", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package pl.pocztapolska.sledzenie;
